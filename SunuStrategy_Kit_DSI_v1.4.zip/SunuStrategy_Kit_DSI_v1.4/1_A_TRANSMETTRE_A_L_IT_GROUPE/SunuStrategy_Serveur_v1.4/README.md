# SunuStrategy 1.4 — paquet d'installation serveur (Groupe SUNU)

SunuStrategy est l'outil de pilotage du plan stratégique du **Groupe SUNU** — assurances Vie et IARD (zones, pays, filiales, agences) et pôle bancaire (DG SIH, banques) — sur une installation unique : priorités, objectifs stratégiques, KPI, plans d'actions, tâches, circuit de validation des mises à jour, revues et reporting.

Cette version est **multi-utilisateurs** : les données sont centralisées dans une base PostgreSQL, chaque collaborateur se connecte avec un compte nominatif, et toutes les règles (droits, circuit de validation, justificatifs, délégations) sont contrôlées par le serveur.

## Nouveautés de la version 1.4

| Domaine | Evolution |
|---|---|
| Arbitrage du portefeuille | Les actions créées par les directions sont **proposées** ; la Direction PBP les **retient** ou les **écarte** (motif), et peut **abandonner** puis réactiver une action en cours. Seules les actions retenues entrent dans l'avancement, les alertes, les relances et les consolidations. Décisions tracées, notifiées dans l'outil |
| Notation | Pertinence, faisabilité, impact, délai (1 à 5), note pondérée sur 5 et niveau (Excellent, Bon, Moyen, Faible) ; pondération paramétrable (Administration › Portefeuille) |
| Valeur | Impacts attendus et constatés sur le chiffre d'affaires et le résultat net, rendement attendu (résultat net / coût), criticité |
| Résultats | Indicateur de résultat par action (cible, réalisé, taux), impacts clients non financiers (NPS, CSAT…), **bilan de clôture** (cible atteinte, partiellement, non atteinte) et alerte « bilan attendu » |
| Pilotage | Menu **Portefeuille & arbitrage** : actions à arbitrer, matrice impact × faisabilité, valeur et résultats par priorité, objectif ou direction ; export Excel enrichi |
| Import Excel | Colonnes facultatives de valeur dans l'onglet Plans d'actions (rétrocompatible avec les classeurs 1.3) |
| Compatibilité | Aucune migration de base : les plans existants sont considérés comme retenus, sans notation |

## Nouveautés de la version 1.3

| Domaine | Evolution |
|---|---|
| Interface bilingue | Boutons **FR / EN** dans l'en-tête et sur l'écran de connexion, pour les filiales anglophones : menus, écrans, messages, notifications, administration et rapports PDF / Excel exportés. Bascule instantanée, choix mémorisé par navigateur, sans paramétrage serveur |
| Périmètre de la traduction | Les données saisies (référentiel, intitulés, commentaires) restent dans leur langue de saisie ; les modèles d'import et le fichier d'accès restent en français (en-têtes lus par l'outil) ; les e-mails sont envoyés en français |

## Nouveautés de la version 1.2

| Domaine | Evolution |
|---|---|
| Périmètre Groupe | Jeu de démonstration **Groupe** (`SEED=demo-groupe` : 6 zones, 17 pays, 30 filiales Vie / IARD, SUNU Bank Sénégal et SUNU Bank Togo, fictif) ; référentiel Excel Groupe d'exemple ; vues Zones & filiales, Pôle bancaire SIH, Profitability Overview assurance et banque ; visa final DG SIH pour les banques |
| Poste de test | Démonstration Groupe par défaut |

## Nouveautés de la version 1.1

| Domaine | Evolution |
|---|---|
| Connexion | Identifiant = **adresse e-mail professionnelle** (`LOGIN_MODE=email`, compatible annuaire via `userPrincipalName` / `mail`) ; bouton d'affichage du mot de passe ; « Se souvenir de moi » ; champs reconnus par le gestionnaire de mots de passe du navigateur |
| Délégation | **Absences** déclarées par la Direction PBP (suppléant et période, redirection automatique des validations) et **réaffectation** d'une étape en attente, avec motif, quatre yeux et piste d'audit |
| Notifications dans l'outil | Cloche, onglet **« Pour moi »** : validations attendues, suivi des demandes, tâches confiées, suppléances |
| Notifications par e-mail | Envoi par le **relais SMTP interne** : validation attendue, demande transmise / validée / rejetée, étape réaffectée, tâche confiée, suppléance, **récapitulatif quotidien des retards** ; file d'attente avec reprise automatique ; mode recette (redirection vers une adresse) |
| Reprise d'un pilote (le cas échéant) | Chargement intégral des données du pilote SharePoint (référentiel, historique, validations, absences, justificatifs) |
| Sécurité | Dépendances mises à jour (`npm audit` : 0 vulnérabilité) |

## Contenu du paquet

| Dossier | Contenu |
|---|---|
| `app/` | Application compilée, prête à exécuter (serveur Node.js, interface, dépendances, jeu de démonstration) |
| `docker/` | `Dockerfile`, `docker-compose.yml` (application + PostgreSQL), modèle de configuration `.env.example` |
| `deploy/` | Installation sans Docker : service systemd, configuration nginx (HTTPS), modèle de configuration |
| `scripts/` | Sauvegarde et restauration de la base |
| `docs/` | Prérequis, installation, exploitation, sécurité, architecture et recette |
| `test-poste/` | Test sur un ordinateur Windows avec Docker Desktop, en double-clic (données fictives) |

## Démarrage rapide (Docker)

```bash
cd docker
cp .env.example .env
chmod 600 .env
# renseigner au minimum POSTGRES_PASSWORD (et INITIAL_ADMIN_PASSWORD) ; messagerie et annuaire si disponibles
docker compose up -d --build
docker compose logs app | grep -i "admin"
```

Puis ouvrir l'adresse publiée par le reverse proxy HTTPS, se connecter avec l'identifiant `admin`, remplacer le mot de passe provisoire, et charger les données (import du référentiel Excel ; reprise d'un pilote le cas échéant).

Le détail est dans `docs/01_Installation.md` ; la fiche `docs/00_Prerequis_techniques.pdf` résume ce que l'infrastructure doit fournir.

## Prérequis

- Serveur Linux 64 bits : 2 vCPU, 4 Go de RAM, 40 Go de disque (jusqu'à 500 utilisateurs).
- Docker 24+ avec Compose v2, **ou** Node.js 22 LTS et PostgreSQL 14+ (installation sans Docker).
- Un nom DNS interne et un certificat TLS émis par l'autorité interne.
- Facultatif : un compte de service de l'annuaire (Active Directory) ; l'adresse du relais SMTP interne.

Aucun accès Internet n'est nécessaire à l'exécution.
