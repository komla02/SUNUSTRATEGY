#!/usr/bin/env bash
# SunuStrategy — restauration d'une sauvegarde (remplace TOUTES les données actuelles)
# Usage :
#   Docker      : MODE=docker ./restauration.sh sauvegardes/sunustrategy_AAAAMMJJ_HHMMSS.dump
#   Sans Docker : DATABASE_URL=postgres://... ./restauration.sh fichier.dump   (arrêter le service avant)
set -euo pipefail
FICHIER="${1:?Indiquer le fichier de sauvegarde à restaurer}"
[ -f "$FICHIER" ] || { echo "Fichier introuvable : $FICHIER"; exit 1; }
read -r -p "Toutes les données actuelles seront remplacées par $FICHIER. Taper RESTAURER pour confirmer : " OK
[ "$OK" = "RESTAURER" ] || { echo "Abandon."; exit 1; }
if [ "${MODE:-}" = "docker" ]; then
  COMPOSE="docker compose -f docker/docker-compose.yml --env-file docker/.env"
  $COMPOSE stop app
  $COMPOSE exec -T db sh -c 'pg_restore -U "$POSTGRES_USER" -d "$POSTGRES_DB" --clean --if-exists --no-owner --single-transaction' < "$FICHIER"
  $COMPOSE start app
else
  : "${DATABASE_URL:?Renseigner DATABASE_URL}"
  pg_restore --dbname="$DATABASE_URL" --clean --if-exists --no-owner --single-transaction "$FICHIER"
  echo "Redémarrer le service : sudo systemctl start sunustrategy"
fi
echo "$(date '+%F %T') restauration terminée depuis $FICHIER"
