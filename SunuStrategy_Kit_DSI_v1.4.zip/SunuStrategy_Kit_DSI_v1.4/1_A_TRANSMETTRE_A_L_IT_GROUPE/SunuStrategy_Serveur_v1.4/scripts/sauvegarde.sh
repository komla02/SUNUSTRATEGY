#!/usr/bin/env bash
# SunuStrategy — sauvegarde de la base (référentiel, comptes, justificatifs, journaux)
# Usage :
#   Docker      : MODE=docker ./sauvegarde.sh            (depuis le dossier du paquet)
#   Sans Docker : DATABASE_URL=postgres://... ./sauvegarde.sh
# Variables : DOSSIER (défaut ./sauvegardes), RETENTION_JOURS (défaut 30)
# Planification conseillée (cron, chaque nuit à 1 h) : 0 1 * * * cd /opt/sunustrategy && MODE=docker ./scripts/sauvegarde.sh >> /var/log/sunustrategy-sauvegarde.log 2>&1
set -euo pipefail
DOSSIER="${DOSSIER:-./sauvegardes}"
RETENTION_JOURS="${RETENTION_JOURS:-30}"
mkdir -p "$DOSSIER"
chmod 700 "$DOSSIER"
FICHIER="$DOSSIER/sunustrategy_$(date +%Y%m%d_%H%M%S).dump"
if [ "${MODE:-}" = "docker" ]; then
  COMPOSE="docker compose -f docker/docker-compose.yml --env-file docker/.env"
  $COMPOSE exec -T db sh -c 'pg_dump -U "$POSTGRES_USER" -d "$POSTGRES_DB" -Fc' > "$FICHIER"
else
  : "${DATABASE_URL:?Renseigner DATABASE_URL}"
  pg_dump --dbname="$DATABASE_URL" -Fc > "$FICHIER"
fi
chmod 600 "$FICHIER"
TAILLE=$(du -h "$FICHIER" | cut -f1)
# contrôle de lisibilité de l'archive
pg_restore --list "$FICHIER" > /dev/null 2>&1 || { [ "${MODE:-}" = "docker" ] && docker compose -f docker/docker-compose.yml --env-file docker/.env exec -T db pg_restore --list < "$FICHIER" > /dev/null; } || { echo "ERREUR : archive illisible $FICHIER"; exit 1; }
echo "$(date '+%F %T') sauvegarde OK : $FICHIER ($TAILLE)"
find "$DOSSIER" -name 'sunustrategy_*.dump' -type f -mtime +"$RETENTION_JOURS" -print -delete | sed 's/^/supprimée (rétention) : /'
