# 1. Installation

## 1.1 Architecture cible

```
 Postes des collaborateurs (navigateur Edge / Chrome, réseau du Groupe)
                     │  HTTPS (443)
                     ▼
   Reverse proxy HTTPS (nginx, F5, IIS ARR…) — certificat interne
                     │  HTTP (8080, réseau local du serveur)
                     ▼
   SunuStrategy (Node.js 22) ──────────► Annuaire AD (LDAPS 636, facultatif)
                     │            └────► Relais SMTP interne (25 / 587, facultatif)
                     │  PostgreSQL (5432, non exposé)
                     ▼
   PostgreSQL 16 — référentiel, comptes, justificatifs, file d'envoi des e-mails, journaux
```

Un seul conteneur (ou service) applicatif. La base n'est jamais exposée aux postes de travail. Une seule installation peut servir plusieurs entités du Groupe.

## 1.2 Dimensionnement

| Utilisateurs | Serveur applicatif + base | Disque |
|---|---|---|
| jusqu'à 500 | 2 vCPU, 4 Go RAM | 40 Go (dont justificatifs) |
| 500 à 2 000 | 4 vCPU, 8 Go RAM | 100 Go |

L'espace disque dépend surtout des justificatifs déposés (10 Mo maximum par fichier). Un environnement de recette de 2 vCPU / 4 Go est recommandé.

## 1.3 Option A — Docker (recommandée)

Prérequis : Docker 24+ et Compose v2 ; accès au registre d'images interne (ou Docker Hub) pour les images de base `node:22-alpine` et `postgres:16-alpine`.

1. Copier le paquet sur le serveur, par exemple dans `/opt/sunustrategy`.
2. Préparer la configuration :
   ```bash
   cd /opt/sunustrategy/docker
   cp .env.example .env && chmod 600 .env
   ```
   Renseigner au minimum :
   - `POSTGRES_PASSWORD` : 24 caractères ou plus, lettres et chiffres ;
   - `INITIAL_ADMIN_PASSWORD` : mot de passe provisoire du compte `admin` (sinon il est généré et affiché une seule fois dans les journaux) ;
   - `SEED=vierge` en production (base vide) ; pour une démonstration : `SEED=demo-groupe` (Groupe SUNU fictif : assurances Vie et IARD par zone et pays, pôle bancaire SIH) ou `SEED=demo-sbsn` (SUNU Bank Sénégal seule, fictif) ;
   - `LOGIN_MODE=email` (connexion par adresse e-mail professionnelle, recommandé) ;
   - messagerie et annuaire si disponibles (§ 1.7 et § 1.8).
3. Construire et démarrer :
   ```bash
   docker compose up -d --build
   docker compose ps          # app et db « healthy »
   docker compose logs app    # « SunuStrategy 1.4.0 à l'écoute sur le port 8080 »
   ```
4. Configurer le reverse proxy HTTPS (§ 1.5).

Si les serveurs n'ont pas accès à un registre d'images : construire l'image sur un poste connecté puis la transférer.
```bash
docker build -f docker/Dockerfile -t sunustrategy:1.4.0 .
docker pull postgres:16-alpine
docker save sunustrategy:1.4.0 postgres:16-alpine | gzip > sunustrategy-images.tar.gz
# sur le serveur cible
docker load < sunustrategy-images.tar.gz
```

Certificats internes (annuaire LDAPS, relais SMTP en TLS) : créer `docker/certs/`, y déposer le certificat de l'autorité interne et décommenter le volume `./certs:/certs:ro` dans `docker-compose.yml`.

## 1.4 Option B — sans Docker (service systemd)

Prérequis : Node.js 22 LTS, PostgreSQL 14 ou supérieur.

```bash
# base de données
sudo -u postgres psql -c "CREATE USER sunustrategy PASSWORD 'MOT_DE_PASSE';"
sudo -u postgres psql -c "CREATE DATABASE sunustrategy OWNER sunustrategy;"

# application
sudo useradd --system --home /opt/sunustrategy --shell /usr/sbin/nologin sunustrategy
sudo mkdir -p /opt/sunustrategy /etc/sunustrategy
sudo cp -r app /opt/sunustrategy/
sudo cp deploy/sunustrategy.env.example /etc/sunustrategy/sunustrategy.env
sudo chown -R root:root /opt/sunustrategy
sudo chown sunustrategy /etc/sunustrategy/sunustrategy.env && sudo chmod 600 /etc/sunustrategy/sunustrategy.env
# éditer /etc/sunustrategy/sunustrategy.env (DATABASE_URL, INITIAL_ADMIN_PASSWORD, LOGIN_MODE, messagerie…)

sudo cp deploy/sunustrategy.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now sunustrategy
sudo journalctl -u sunustrategy -f
```

Les dépendances sont incluses dans `app/node_modules` : aucun téléchargement n'est nécessaire. Elles sont écrites en JavaScript pur ; le même dossier fonctionne aussi sur Windows Server avec Node.js 22, en service via l'outil de service standard de la DSI (WinSW, NSSM…), derrière IIS ARR pour le HTTPS.

## 1.5 HTTPS (obligatoire en production)

Exemple nginx : `deploy/nginx-sunustrategy.conf`. Points à respecter :

- terminer le TLS sur le reverse proxy avec un certificat de l'autorité interne ;
- transmettre `X-Forwarded-Proto` et `X-Forwarded-For` ;
- `client_max_body_size 400m` le jour de la reprise des données du pilote (§ 1.9), `60m` ensuite ;
- côté application : `TRUST_PROXY=true` et `COOKIE_SECURE=true`.

## 1.6 Premier démarrage

1. Ouvrir `https://sunustrategy.<domaine interne>`.
2. Se connecter avec l'identifiant `admin` (saisi dans le champ « Adresse e-mail professionnelle ») et le mot de passe provisoire ; le remplacer (écran imposé).
3. Charger les données du Groupe : **Administration › Import / Export** → référentiel Excel (modèle vierge, ou exemple `SunuStrategy_Groupe_Referentiel_Exemple.xlsx` à adapter) → import contrôlé. Un seul classeur décrit tout le Groupe : directions du siège, Direction PBP, directions de zone, pays et filiales d'assurance, DG SIH et banques, puis priorités, objectifs, KPI, plans d'actions (rattachés à un pays ou à une banque) et tâches. Voir § 1.9 pour intégrer le pilote de SUNU Bank Sénégal.
4. Créer les accès : **Administration › Comptes & sécurité**.
   - Un compte est créé automatiquement pour chaque utilisateur du référentiel. Avec `LOGIN_MODE=email`, l'identifiant est l'**adresse professionnelle** de l'onglet Utilisateurs ; il reste modifiable (crayon).
   - Mode mot de passe local : bouton **Générer les mots de passe initiaux** → un fichier Excel confidentiel est téléchargé (identifiant + mot de passe provisoire par collaborateur, à remplacer à la première connexion).
   - Mode annuaire : aucun mot de passe à distribuer, chacun se connecte avec son adresse et son mot de passe Windows.
5. Paramétrer : **Administration › Paramètres** (circuit de validation, justificatif obligatoire) et **Périodes** (date de situation automatique ou figée).
6. Vérifier la messagerie : **Administration › Comptes & sécurité › Notifications par e-mail** → « Envoyer un test ».

## 1.7 Connexion à l'annuaire (Active Directory)

Dans `.env` :

```
AUTH_MODE=ldap                # ou mixed pendant la transition
LOGIN_MODE=email
LDAP_URL=ldaps://dc01.sunugroup.local:636
LDAP_BIND_DN=CN=svc-sunustrategy,OU=Comptes de service,DC=sunugroup,DC=local
LDAP_BIND_PASSWORD=...        # compte de service en lecture seule
LDAP_SEARCH_BASE=OU=Utilisateurs,DC=sunugroup,DC=local
LDAP_SEARCH_FILTER=(&(objectClass=user)(|(userPrincipalName={{login}})(mail={{login}})))
LDAP_CA_FILE=/certs/ac-interne.pem
```

- `LOGIN_MODE=email` : l'utilisateur saisit son adresse ; l'annuaire le retrouve par `userPrincipalName` ou `mail`. Avec `LOGIN_MODE=identifiant`, utiliser `(&(objectClass=user)(sAMAccountName={{login}}))`.
- Le compte `admin` reste local en toutes circonstances (accès de secours si l'annuaire est indisponible).
- `mixed` : l'annuaire est essayé en premier, puis le mot de passe local (comptes hors annuaire, prestataires).
- Pour restreindre l'accès à un groupe AD, ajouter au filtre : `(memberOf=CN=GG-SunuStrategy,OU=Groupes,DC=sunugroup,DC=local)`.

## 1.8 Notifications par e-mail (relais SMTP interne)

Dans `.env` :

```
MAIL_ENABLED=true
SMTP_HOST=smtp.sunugroup.local
SMTP_PORT=25                  # 587 + SMTP_REQUIRE_TLS=true, ou 465 + SMTP_SECURE=true
SMTP_USER=                    # vide pour un relais autorisé par adresse IP
SMTP_PASSWORD=
MAIL_FROM=SunuStrategy <sunustrategy@sunugroup.com>
APP_URL=https://sunustrategy.sunugroup.local
MAIL_ALERTS=daily             # daily (jours ouvrés), weekly (lundi), off
MAIL_ALERT_HOUR=7
MAIL_REDIRECT_TO=             # recette : rediriger tous les messages vers une adresse
```

- Le relais doit accepter l'adresse IP du serveur (ou le compte `SMTP_USER`) et l'expéditeur `MAIL_FROM`.
- Les messages sont mis en **file d'attente** dans la base, puis envoyés en arrière-plan ; en cas d'indisponibilité du relais, ils sont renvoyés automatiquement (6 tentatives espacées), sans bloquer les utilisateurs.
- En **recette**, renseigner `MAIL_REDIRECT_TO` : tous les messages arrivent dans une seule boîte, le destinataire réel est rappelé dans l'objet.
- Contrôle : Administration › Comptes & sécurité › **Notifications par e-mail** (état, message de test, derniers envois, relance des envois en échec, envoi immédiat des alertes du jour).

## 1.9 Reprise des données du pilote SharePoint (le cas échéant)

Ce paragraphe ne s'applique que si un pilote « dossier partagé » a été mené. Sinon, les données sont chargées par import du référentiel Excel (Administration › Import / Export) : passer au § 1.10.

Le pilote (version « dossier partagé ») se transfère intégralement : référentiel, avancements, demandes et circuit de validation, commentaires, absences, piste d'audit et justificatifs.

**Déploiement Groupe** : la reprise et l'import Excel remplacent chacun l'ensemble des données. Deux enchaînements possibles :
- *Référentiel Groupe d'abord* (recommandé) : dans le pilote, **Exporter la base** (Excel réimportable : référentiel et avancements de SUNU Bank Sénégal) ; recopier ses lignes dans le classeur du Groupe ; importer le classeur Groupe. L'historique du pilote (demandes, commentaires, justificatifs) est conservé à part (fichier de reprise archivé).
- *Pilote d'abord* : reprise intégrale du pilote (ci-dessous) pour une mise en service immédiate de SUNU Bank Sénégal, puis import du référentiel Groupe complet (intégrant SUNU Bank Sénégal) le jour de l'extension.

1. Dans le pilote, compte administrateur : **Administration › Accès du pilote › Passage à la version serveur › Exporter pour la version serveur**. Le fichier `.json` produit n'est **pas chiffré** : le transmettre par un canal sûr.
2. Dans la version installée, compte `admin` : **Administration › Import / Export › Reprendre les données du pilote** → contrôle des volumes → confirmation.
3. Les comptes sont créés avec l'adresse e-mail de chaque participant ; les mots de passe du pilote ne sont pas repris (annuaire, ou mots de passe initiaux à générer).
4. Supprimer le fichier de reprise ; passer le dossier SharePoint du pilote en lecture seule, puis l'archiver.

## 1.10 Vérifications

```bash
curl -s http://127.0.0.1:8080/api/health        # {"status":"ok","version":"1.4.0"}
curl -sI https://sunustrategy.<domaine>/ | grep -i content-security-policy
```

La fiche de recette (`docs/05_Recette.md`) liste les contrôles fonctionnels à dérouler avant l'ouverture aux utilisateurs.
