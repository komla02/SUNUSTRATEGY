# 5. Fiche de recette

A dérouler sur l'environnement de recette, avec le référentiel réel ou le jeu de démonstration (`SEED=demo-sbsn`).

| # | Contrôle | Résultat attendu | OK |
|---|---|---|---|
| **Installation** | | | |
| 1 | `GET /api/health` | `{"status":"ok"}` | ☐ |
| 2 | Accès en HTTP | Redirection vers HTTPS | ☐ |
| 3 | En-têtes de la page d'accueil | `Content-Security-Policy`, `Strict-Transport-Security`, `X-Frame-Options` présents | ☐ |
| **Comptes** | | | |
| 4 | Connexion `admin` avec le mot de passe provisoire | Changement de mot de passe imposé | ☐ |
| 5 | Import du référentiel Excel | Contrôle affiché, puis données chargées | ☐ |
| 6 | Générer les mots de passe initiaux | Fichier Excel confidentiel téléchargé | ☐ |
| 7 | 5 mots de passe erronés sur un compte | Compte verrouillé, événement au journal de sécurité | ☐ |
| 8 | Déverrouillage par l'administrateur | Connexion de nouveau possible | ☐ |
| 9 | Désactivation d'un utilisateur connecté | Session fermée immédiatement | ☐ |
| 10 | (annuaire) Connexion avec l'adresse e-mail et le mot de passe Windows | Accès sans mot de passe SunuStrategy | ☐ |
| 10 bis | Connexion avec l'adresse e-mail en majuscules ; bouton œil du mot de passe | Accès accordé ; saisie affichée puis masquée | ☐ |
| **Droits et circuit** | | | |
| 11 | Contributeur : mise à jour d'une de ses tâches | Demande créée, avancement non appliqué | ☐ |
| 12 | Contributeur : clôture sans justificatif | Refusée | ☐ |
| 13 | Dépôt d'un justificatif (PDF) puis clôture | Acceptée et soumise au circuit | ☐ |
| 14 | Dépôt d'un fichier `.exe` ou de plus de 10 Mo | Refusé | ☐ |
| 15 | Demandeur tente de valider sa propre demande | Refusé | ☐ |
| 16 | N+1, responsable de priorité, Direction PBP valident tour à tour | Avancement appliqué à la dernière étape | ☐ |
| 17 | Valideur non désigné tente de valider | Refusé | ☐ |
| 18 | Contributeur tente de modifier une priorité | Bouton absent ; appel direct à l'API refusé | ☐ |
| **Travail à plusieurs** | | | |
| 19 | Commentaire saisi sur le poste A | Visible sur le poste B en moins de 15 s | ☐ |
| 20 | Deux valideurs agissent sur la même demande | Le second reçoit « déjà traitée » | ☐ |
| **Délégation (Direction PBP)** | | | |
| 25 | Déclarer une absence (valideur, suppléant, période) | Les demandes du valideur absent apparaissent « A valider par moi » chez le suppléant | ☐ |
| 26 | Réaffecter une étape en attente à une autre personne, avec motif | Seule la personne désignée peut statuer ; circuit « X (pour Y) » ; audit tracé | ☐ |
| 27 | Tenter de réaffecter au demandeur, ou sans motif | Refusé | ☐ |
| **Notifications** | | | |
| 28 | Cloche › « Pour moi » d'un valideur après une soumission | « Validation attendue » ; disparaît une fois la demande traitée | ☐ |
| 29 | Messagerie : « Envoyer un test » (Comptes & sécurité) | Message reçu dans Outlook, expéditeur `MAIL_FROM` | ☐ |
| 30 | Soumission, validation d'étape, validation finale, rejet | E-mails au demandeur et au valideur attendu (ou à son suppléant) | ☐ |
| 31 | « Envoyer les alertes du jour » | Un récapitulatif par personne ayant des retards ; un second clic n'envoie rien | ☐ |
| 32 | Relais SMTP arrêté pendant une soumission | Action enregistrée ; message renvoyé automatiquement au retour du relais | ☐ |
| **Reprise d'un pilote (le cas échéant)** | | | |
| 33 | Reprendre les données du pilote (fichier d'export) | Référentiel, validations, absences, audit et justificatifs identiques au pilote | ☐ |
| **Périmètre Groupe** | | | |
| 34 | Import du référentiel Groupe (exemple `SunuStrategy_Groupe_Referentiel_Exemple.xlsx` ou référentiel réel) | Zones, pays, banques, plans par pays et par banque chargés ; vues Zones & filiales et Pôle bancaire SIH alimentées | ☐ |
| 35 | Mise à jour d'une tâche d'un plan bancaire | Circuit clos par le visa final de la DG SIH | ☐ |
| 36 | Directeur de Zone, Directeur Pays, DG SIH | Chacun voit et pilote son périmètre ; modification d'une priorité Groupe refusée | ☐ |
| **Interface bilingue** | | | |
| 37 | Ecran de connexion : bouton EN | Libellés, aide et messages d'erreur en anglais | ☐ |
| 38 | Session ouverte : EN, puis navigation (tableau de bord, validations, administration) puis FR | Interface entièrement en anglais puis retour à l'identique en français ; données saisies inchangées | ☐ |
| 39 | Rechargement de la page après choix EN | Langue conservée sur ce navigateur | ☐ |
| 40 | Export d'un rapport PDF et Excel en anglais | Titres, colonnes et onglets en anglais | ☐ |
| **Portefeuille d'actions** | | | |
| 41 | Un directeur crée une action | Statut « Proposée » ; absente de l'avancement et des alertes ; notification « à arbitrer » pour la Direction PBP | ☐ |
| 42 | Direction PBP : Retenir, puis Ecarter une autre action sans motif, puis avec motif | Retenue intégrée au portefeuille ; écart refusé sans motif ; décision tracée et notifiée au responsable | ☐ |
| 43 | Directeur : appel direct à l'API pour retenir sa propre action | Refusé | ☐ |
| 44 | Notation 1 à 5 et impacts saisis sur un plan ; pondération modifiée (Administration › Portefeuille) | Note pondérée et niveau recalculés ; matrice et synthèse à jour | ☐ |
| 45 | Plan terminé : bilan de clôture | Alerte « bilan attendu » avant ; bilan daté et signé par le serveur après | ☐ |
| 46 | Export de la base puis réimport | Sélection, notation, impacts, indicateurs et bilans identiques | ☐ |
| **Exploitation** | | | |
| 21 | Sauvegarde puis restauration sur la recette | Données identiques | ☐ |
| 22 | Redémarrage du serveur | Aucune perte de données, sessions conservées | ☐ |
| 23 | Export de la piste d'audit (CSV) | Toutes les modifications tracées | ☐ |
| 24 | Procédure de secours `--reset-admin-password` | Nouveau mot de passe provisoire | ☐ |

Recette prononcée le ____/____/______ par : ____________________ (DSI) ____________________ (Direction PBP)
