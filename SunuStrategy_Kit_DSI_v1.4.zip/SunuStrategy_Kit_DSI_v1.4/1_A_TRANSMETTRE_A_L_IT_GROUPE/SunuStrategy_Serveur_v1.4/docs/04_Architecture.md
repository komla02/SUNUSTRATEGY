# 4. Architecture technique

## 4.1 Composants

| Composant | Technologie | Rôle |
|---|---|---|
| Interface | React 18, TypeScript, compilée en fichiers statiques | Ecrans, tableaux de bord, exports PDF / Excel |
| Serveur applicatif | Node.js 22, Fastify 5 | API, droits, règles métier, sessions, justificatifs, fichiers de l'interface |
| Base de données | PostgreSQL 14+ (16 recommandé) | Référentiel, comptes, sessions, justificatifs, journaux |
| Annuaire (facultatif) | LDAP / Active Directory | Vérification des identifiants |
| Messagerie (facultatif) | Relais SMTP interne (Nodemailer) | Notifications et récapitulatif des retards, file d'attente en base avec reprise |

La logique métier (calcul des avancements, circuit de validation, droits) est **un seul code**, exécuté par l'interface pour l'affichage immédiat et par le serveur, qui fait foi.

## 4.2 Fonctionnement d'une action

1. L'utilisateur agit (ex. soumission d'un avancement) : l'écran se met à jour immédiatement.
2. L'action est envoyée au serveur avec la session de l'utilisateur.
3. Le serveur contrôle les droits et les données, recalcule l'action sur l'état de référence, enregistre le résultat dans une transaction (avec la piste d'audit), puis répond.
4. L'écran se réaligne sur l'état confirmé. En cas de refus, il revient à l'état réel et affiche le motif.
5. Les autres postes reçoivent les changements à leur prochaine synchronisation (15 s, ou au retour sur la fenêtre).
6. Si la messagerie est activée, le serveur calcule les messages à adresser (demandeur, prochain valideur ou son suppléant, personne désignée, responsable d'une tâche confiée), les inscrit dans la file `mail_outbox` et les envoie en arrière-plan. Les notifications sont aussi affichées dans l'outil (cloche, onglet « Pour moi »).

## 4.3 Modèle de données

| Table | Contenu |
|---|---|
| `entity` | Référentiel : une ligne par élément (priorité, objectif, KPI, plan d'actions, tâche, risque, décision, commentaire, demande de validation, ligne d'audit…), contenu JSON, numéro de séquence pour la synchronisation |
| `account` | Comptes de connexion : identifiant, empreinte du mot de passe, état (provisoire, verrouillé, désactivé), dernière connexion |
| `session` | Sessions actives (empreinte du jeton, expiration, adresse IP) |
| `file_blob` | Contenu des justificatifs (nom, type, taille, empreinte SHA-256) |
| `security_log` | Journal de sécurité |
| `mail_outbox` | File d'envoi des e-mails : destinataire, objet, contenu, état (en attente, envoyé, en échec), tentatives, dernière erreur ; purge à 90 jours |
| `meta`, `schema_migration` | Paramètres techniques et version du schéma |

## 4.4 API

| Méthode | Chemin | Accès |
|---|---|---|
| GET | `/api/health` | libre (supervision) |
| GET | `/api/auth/options` | libre (mode d'identification affiché à l'écran de connexion) |
| POST | `/api/auth/login`, `/api/auth/logout` | libre / session |
| GET | `/api/auth/me` | session |
| POST | `/api/auth/password` | session |
| GET | `/api/state`, `/api/sync` | session |
| POST | `/api/commands` | session — droits contrôlés par action |
| POST | `/api/tasks/:id/attachments` | session — droit sur la tâche |
| GET | `/api/files/:id` | session |
| POST | `/api/admin/import`, `/api/admin/reset` | Administrateur, Direction PBP |
| GET | `/api/admin/accounts`, `/api/admin/security-log`, `/api/admin/audit.csv` | Administrateur, Direction PBP |
| POST | `/api/admin/accounts/:id/reset`, `…/unlock`, `…/login`, `/api/admin/accounts/initial-passwords` | Administrateur, Direction PBP |
| GET / POST | `/api/admin/mail`, `/api/admin/mail/test`, `…/retry`, `…/alerts` | Administrateur, Direction PBP |
| POST | `/api/admin/migrate` (reprise du pilote) | Administrateur uniquement |

## 4.5 Evolutions possibles

- Alimentation automatique des KPI réalisés depuis le datawarehouse ou le reporting (API d'import planifiée).
- Authentification unique SAML / OpenID Connect (Azure AD, ADFS).
- Cloisonnement en lecture par direction.
- Haute disponibilité (deux instances avec coordination par la base).
