# 3. Sécurité

Ce document s'adresse à la DSI et au RSSI pour l'homologation.

## 3.1 Authentification

| Mesure | Mise en œuvre |
|---|---|
| Comptes nominatifs | Un compte par collaborateur du référentiel ; aucun compte partagé |
| Mots de passe | Hachage **scrypt** (N = 32768, sel aléatoire de 16 octets) ; jamais stockés ni journalisés en clair |
| Identifiant | Adresse e-mail professionnelle (`LOGIN_MODE=email`) ou identifiant court ; compte `admin` de secours |
| Politique | 10 caractères minimum, 3 types de caractères, sans l'identifiant, mots trop prévisibles refusés |
| Premier accès | Mot de passe provisoire à usage unique, changement imposé avant tout accès aux données |
| Force brute | Verrouillage du compte après 5 échecs (15 min) ; limitation à 30 tentatives / 5 min par adresse IP ; temps de réponse identique que l'identifiant existe ou non ; message d'erreur générique |
| Annuaire | LDAP / Active Directory (LDAPS, contrôle du certificat, compte de service en lecture seule, échappement des filtres) ; compte `admin` local de secours |

## 3.2 Sessions

- Jeton aléatoire de 256 bits dans un cookie `HttpOnly`, `SameSite=Strict`, `Secure` en HTTPS. Seule l'empreinte SHA-256 du jeton est conservée en base.
- Expiration après 60 min d'inactivité et au plus tard après 10 h.
- Fermeture de toutes les sessions d'un utilisateur à sa désactivation, au changement ou à la réinitialisation de son mot de passe, et au changement de son identifiant.

## 3.3 Contrôle des droits

- **Toutes les règles sont appliquées par le serveur**, pas seulement par l'écran : modification des priorités et objectifs, périmètre de chaque profil, circuit de validation (N+1, responsable de priorité, Direction PBP), principe des quatre yeux, justificatif obligatoire pour clôturer une tâche, gestion des comptes.
- **Délégation encadrée** : seule la Direction PBP déclare une absence (suppléant, période) ou réaffecte une étape ; le motif est obligatoire, le demandeur et les valideurs déjà intervenus ne peuvent pas être désignés (quatre yeux), chaque opération est inscrite dans la piste d'audit.
- Un appel direct à l'API qui contourne l'écran est refusé (code 403) et tracé dans le journal de sécurité.
- Seul un administrateur peut créer, modifier ou réinitialiser un compte administrateur (pas d'élévation de privilège par la Direction PBP).
- Chaque donnée reçue est contrôlée (champs attendus, types, longueurs, valeurs autorisées) avant enregistrement.

**Choix de conception à valider** : tout collaborateur authentifié peut consulter le plan stratégique de la banque en lecture, filtré à l'écran selon son profil. Les droits d'écriture sont strictement limités au périmètre. Si la banque exige un cloisonnement en lecture (par direction), ce point fera l'objet d'une évolution.

## 3.4 Protection de l'application web

| Risque | Protection |
|---|---|
| Injection de script (XSS) | Politique de sécurité du contenu stricte : `script-src 'self'`, aucun script en ligne, aucune ressource externe ; échappement systématique de l'interface |
| Falsification de requête (CSRF) | Cookie `SameSite=Strict` + en-tête applicatif obligatoire + contrôle de l'origine |
| Clickjacking | `frame-ancestors 'none'`, `X-Frame-Options` |
| Injection SQL | Requêtes paramétrées exclusivement |
| Fichiers déposés | Liste blanche d'extensions, type MIME imposé par le serveur, 10 Mo maximum, téléchargement forcé (`Content-Disposition: attachment`, `nosniff`), empreinte SHA-256 conservée |
| Fuite de données sur le poste | Aucune donnée métier n'est conservée dans le navigateur (seules les préférences d'affichage) ; réponses `Cache-Control: no-store` |
| Exposition réseau | Base PostgreSQL non publiée ; conteneur non privilégié, système de fichiers en lecture seule, capacités Linux retirées |

## 3.5 Traçabilité

- **Piste d'audit métier** : chaque création, modification, soumission, validation ou rejet (utilisateur, date, champ, ancienne et nouvelle valeur, commentaire), conservée intégralement en base.
- **Journal de sécurité** : connexions, échecs, verrouillages, mots de passe, comptes, imports, reprise du pilote, réinitialisations, messages de test, actions refusées, avec adresse IP.
- Les horodatages sont produits par le serveur (heure réelle lorsque la date de situation est automatique, réglage par défaut en production) ; l'utilisateur ne peut pas les modifier.

## 3.6 Données

- Hébergement exclusivement sur l'infrastructure du Groupe ; aucun appel vers Internet (polices, scripts et styles servis localement).
- **E-mails** : envoyés uniquement par le relais SMTP interne, un message nominatif par destinataire ; contenu limité à la référence, l'intitulé, l'étape et l'échéance (ni avancement, ni commentaire, ni pièce jointe) ; en-têtes « message automatique » ; historique des envois purgé après 90 jours.
- **Fichier de reprise du pilote** : il contient les données en clair ; le transmettre par un canal sûr et le supprimer après la reprise (opération réservée au compte administrateur et tracée).
- **Dépendances** : `npm audit` sans vulnérabilité connue à la date de livraison (octobre 2026).
- Données personnelles traitées : nom, fonction, direction, adresse professionnelle, identifiant, traces de connexion. Hébergement centralisé à Abidjan : vérifier avec la Conformité que le cadre intra-groupe couvre les données des entités (Sénégal : CDP, loi n° 2008-12 ; Côte d'Ivoire : ARTCI).
- Justificatifs stockés en base (inclus dans les sauvegardes).

## 3.7 Recommandations pour la DSI

1. HTTPS obligatoire avec certificat interne ; HTTP redirigé.
2. Serveur dans une zone réseau interne ; flux entrant 443 depuis les postes seulement ; flux sortants 636 vers l'annuaire et 25/587 vers le relais SMTP seulement.
3. Secrets (`.env`) en droits 600, ou secrets Docker.
4. Sauvegardes quotidiennes chiffrées, test de restauration trimestriel.
5. Test d'intrusion avant ouverture, puis à chaque version majeure.
6. Authentification par l'annuaire (`AUTH_MODE=ldap`) pour bénéficier de la politique de mots de passe et de la MFA de la banque si elle est en place sur l'AD.
7. Revue trimestrielle des comptes actifs (export depuis Comptes & sécurité).
