@echo off
title SunuStrategy - journal
cd /d "%~dp0..\docker"
docker compose ps
echo.
docker compose logs --tail 80 app
echo.
pause
