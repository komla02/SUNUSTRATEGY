@echo off
title SunuStrategy - remise a zero du test
cd /d "%~dp0..\docker"
echo.
echo  ATTENTION : toutes les donnees du test seront effacees
echo  (comptes, mises a jour, justificatifs).
echo.
set /p ok=Tapez OUI pour confirmer : 
if /i not "%ok%"=="OUI" (
  echo  Abandon.
  goto fin
)
docker compose down -v
echo.
echo  Donnees effacees. Relancez 1_DEMARRER_LE_TEST.bat :
echo  le jeu de demonstration sera recharge et le mot de passe admin redevient Pilotage+2026x.
:fin
echo.
pause
