@echo off
setlocal
title SunuStrategy - test sur mon poste
cd /d "%~dp0..\docker"

echo.
echo  ==========================================================
echo   SunuStrategy 1.4 - test sur ce poste (donnees fictives)
echo  ==========================================================
echo.

where docker >nul 2>&1
if errorlevel 1 (
  echo  [ERREUR] Docker Desktop n'est pas installe sur ce poste.
  echo  Installez-le depuis https://www.docker.com/products/docker-desktop/ puis relancez ce fichier.
  goto fin
)
docker info >nul 2>&1
if errorlevel 1 (
  echo  [ERREUR] Docker Desktop n'est pas demarre.
  echo  Ouvrez Docker Desktop, attendez l'indication "Engine running", puis relancez ce fichier.
  goto fin
)

if exist .env (
  echo  Configuration existante conservee : docker\.env
) else (
  echo  Creation de la configuration de test : docker\.env
  > .env echo POSTGRES_DB=sunustrategy
  >> .env echo POSTGRES_USER=sunustrategy
  >> .env echo POSTGRES_PASSWORD=Test2026abc
  >> .env echo APP_BIND=127.0.0.1
  >> .env echo APP_PORT=8080
  >> .env echo SEED=demo-groupe
  >> .env echo INITIAL_ADMIN_PASSWORD=Pilotage+2026x
  >> .env echo TRUST_PROXY=false
  >> .env echo COOKIE_SECURE=false
  >> .env echo AUTH_MODE=local
  >> .env echo LOG_LEVEL=info
)

echo.
echo  Construction et demarrage (le premier lancement peut prendre plusieurs minutes)...
echo.
docker compose up -d --build
if errorlevel 1 (
  echo.
  echo  [ERREUR] Le demarrage a echoue. Faites une capture de cette fenetre.
  goto fin
)

echo.
echo  Attente de la disponibilite de l'application...
set /a n=0
:attente
set /a n+=1
curl -s http://localhost:8080/api/health | find "ok" >nul 2>&1
if not errorlevel 1 goto pret
if %n% geq 60 (
  echo  [ERREUR] L'application ne repond pas apres 2 minutes.
  echo  Journal de l'application :
  docker compose logs --tail 40 app
  goto fin
)
timeout /t 2 /nobreak >nul
goto attente

:pret
echo.
echo  ----------------------------------------------------------
echo   SunuStrategy est demarre : http://localhost:8080
echo.
echo   Premiere connexion :  identifiant  admin
echo                         mot de passe Pilotage+2026x
echo   (un nouveau mot de passe vous sera demande)
echo  ----------------------------------------------------------
start "" http://localhost:8080

:fin
echo.
pause
