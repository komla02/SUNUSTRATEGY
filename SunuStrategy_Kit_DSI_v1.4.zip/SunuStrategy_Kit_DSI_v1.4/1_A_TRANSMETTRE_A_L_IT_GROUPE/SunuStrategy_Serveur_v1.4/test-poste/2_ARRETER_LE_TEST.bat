@echo off
title SunuStrategy - arret du test
cd /d "%~dp0..\docker"
echo.
echo  Arret de SunuStrategy (les donnees sont conservees)...
docker compose down
echo.
echo  Termine. Relancez 1_DEMARRER_LE_TEST.bat pour reprendre.
echo.
pause
